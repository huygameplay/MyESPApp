package com.esp.menucusuc;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        Button btn = new Button(this);
        btn.setText("BAT ESP CUC SUC");
        btn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                Toast.makeText(this, "Cap quyen overlay roi bam lai", Toast.LENGTH_SHORT).show();
            } else {
                startService(new Intent(this, OverlayService.class));
                Toast.makeText(this, "ESP dang chay, vao game di", Toast.LENGTH_SHORT).show();
            }
        });
        setContentView(btn);
    }
}